#!/bin/bash
echo 'Installing GPT Raja Touch...'
